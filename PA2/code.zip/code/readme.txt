This is a read me file about COMP 4211 PA2 - Written by CHEN,Yifei 20328874

my whole code are divided by  main cells.   For checking, just run it subsequently

1. Preparation Part :
   
	this part contains the CNN classifier, Decoder's definition and relevant train	 	functions.

2. CNN (Scratch) main function :
        Some following cells call the main function with different parameters settings

3. CNN (Scratch) testing phase function:
        With one cell behind calling this function

4. CNN (Pretrained) main function :
	similar with 2

5. CNN (Pretrained) test function :
	similar with 3

6. Decoder with CAE main function: 
	similar with 2

7. Decoder with CAE test function:
	similar with 3

For each part, just run it orderly.